import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GameBoard {
    private ArrayList<Person> people;
    private Person target;
    private int faceUp, guessesMade;
    Guess guessHandler;
    private boolean gameEnded = false;
    private PersonType chosenType;
    GuessWhoGame guessWhoGame = new GuessWhoGame();
    
    
    private String[] names = Person.names;
    

	Scanner input = new Scanner(System.in);
    public GameBoard(List<Player> players) {
        this.people = new ArrayList<Person>();
        this.guessesMade = 0;
        this.faceUp = people.size();            
        initializeGame();
    }
    
    public GameBoard(List<Player> players, PersonType chosenType) {
        this.people = new ArrayList<Person>();
        this.chosenType = chosenType;
        this.guessesMade = 0;
        this.faceUp = people.size();            
        initializeGame();
    }


    public void updateGameState() {
        // This method might be called after a guess to update the game state
        this.faceUp = people.size(); // Update faceUp to the current number of "face up" people
        this.guessesMade++; // Increment guessesMade
    }
    
    private void initializeGame() {
        // Clear the current list of people
        people.clear();
        createPersons();
        
        // Create new Person objects with names and add them to the list
        for(String name : names) {
            people.add(new Person(name));
        }
        
        // Randomly select a target Person
        this.target = people.get((int) (Math.random() * people.size()));
        this.guessHandler = new Guess(people, target);
        
        // Reset the number of people that are "faceUp" (still in the game)
        faceUp = people.size();
        
        // Reset the number of guesses made
        guessesMade = 0;
    }

    public ArrayList<Person> createPersons() {
    	ArrayList<Person> personList = new ArrayList<>();
   	
        for(int i = 0; i<26; ++i) {
            Person person = new Person(Person.names[i], chosenType);
            personList.add(person);
        }
        return personList;   
        
    }
    
    
    
    public void start(List<Player> players) {
        initializeGame(); // Set up the game
        boolean continueGame = true;
        
        for (Player player: players) {
            while (continueGame) {
                display();
                continueGame = player.makeGuess(this); // Use the result of guess to control the game loop
            }
        }
        
    }
        // Now, after setting gameEnded to true, the method will end and return control to the calling method.
    public void display() {
        for (Person person : people) {
            if (person.faceUp) {
                person.display();
            }
        }
    }

    public boolean guess() {
        String guessType = "";
        guessType = guessWhoGame.ChoseGuessNorT();
        if (guessType.equalsIgnoreCase("N")) {
            // Return the result of handleNameGuess which is now boolean
            boolean result = guessHandler.handleNameGuess();
            
            // Prompt for restart after making the name guess
            boolean playAgain = GuessWhoGame.promptForRestart();
            if (playAgain) {
                guessWhoGame.initGameBoard();
            }
    
            return result;
        } else if (guessType.equalsIgnoreCase("T")) {
            guessHandler.handleTraitGuess(); // Assuming this method doesn't end the game
            return true; // Continue the game after a trait guess
        } else {
            System.out.println("Invalid input. Please enter 'T' for trait or 'N' for name.");
            return true; // Continue the game for invalid input
        }
    }
  
}
