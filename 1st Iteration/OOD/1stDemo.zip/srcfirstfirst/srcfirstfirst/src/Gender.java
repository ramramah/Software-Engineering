import java.util.Arrays;
public class Gender extends Trait {
    public Gender() {
        super(Arrays.asList("Male", "Female"));
    }
}
