import java.util.Arrays;
public class Eye extends Trait {
    public Eye() {
        super(Arrays.asList("Black", "Brown", "Golden", "Green", "Blue"));
    }
}
