import java.util.List;
import java.util.ArrayList;
public abstract class Trait {
    protected List<String> values; // Using String to represent the values of the trait
    protected String value; // The actual value for the trait
    protected boolean isGuessed = false;

    public Trait(List<String> values) {
        this.values = new ArrayList<>(values);
        this.value = values.get((int) (Math.random() * values.size())); // Correctly cast the result to int
        this.isGuessed = false;
    }
    
    public void markAsGuessed() {
        isGuessed = true;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public List<String> getValues() {
        return values;
    }

    public void guessValue(String guess) {
        if (values.contains(guess)) {
            setValue(guess);
            isGuessed = true;
        } else {
            values.remove(guess);
        }
    }

    public boolean isGuessed() {
        return isGuessed;
    }

    public void eliminateNonMatchingValues(String guess) {
        values.removeIf(v -> !v.equals(guess));
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + ": " + value;
    }
}
