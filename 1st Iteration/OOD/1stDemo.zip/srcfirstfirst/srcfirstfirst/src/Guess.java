import java.util.List;
import java.util.Scanner;

public class Guess {
    private List<Person> people;
    private Person target;
    GuessWhoGame guessWhoGame = new GuessWhoGame();
    

    public Guess(List<Person> people, Person target) {
        this.people = people;
        this.target = target;
    }

	Scanner input = new Scanner(System.in);
    public boolean handleNameGuess() {
        // Display the list of names of characters that are still in the game
        System.out.println("Choose a name to guess from the list:");
        for (int i = 0; i < people.size(); i++) {
            if (people.get(i).faceUp) { // Assuming that the 'faceUp' attribute indicates if a character is still in the game
                System.out.println((i + 1) + ". " + people.get(i).name);
            }
        }
    
        
        int nameIndex = guessWhoGame.GuessName(); // Adjust for 0-based index
        
    
        // Check if the input is within the valid range
        // if (nameIndex < 0 || nameIndex >= people.size() || !people.get(nameIndex).faceUp) {
        //     System.out.println("Invalid number or character already eliminated. Please try again.");
        //     return true; // Exit the method if the number is not valid
        // }
    
        String guessedName = people.get(nameIndex).name;
        if (guessedName.equalsIgnoreCase(target.name)) {
            System.out.println("Correct guess! You've won the game!");
            return true; // Return false to indicate that the game should end
        } else {
            System.out.println("Incorrect guess. The character " + guessedName + " is not the target.");
            System.out.println("The target was: " + target.getName());
            return false; // Return false to indicate that the game should end
        }
    }

    
    // This method prompts the player to guess a trait and returns the selected trait's index.
    public void handleTraitGuess() {
        // Display the list of traits with numbers
        for (int i = 0; i < target.traits.size(); i++) {
            System.out.println((i + 1) + ". " + target.traits.get(i).getClass().getSimpleName());
        }
    
        int traitIndex = guessWhoGame.GuessTrait();
    
        if (traitIndex < 0 || traitIndex >= target.traits.size()) {
            System.out.println("Invalid trait number. Please try again.");
            return; // Exit the method
        }
    
        // Display the list of possible values for the chosen trait with numbers
        Trait chosenTrait = target.traits.get(traitIndex);
        List<String> values = chosenTrait.getValues();
        for (int i = 0; i < values.size(); i++) {
            System.out.println((i + 1) + ". " + values.get(i));
        }
    
        System.out.println("Choose the value to guess by number:");
        int valueIndex = input.nextInt() - 1; // Adjust for 0-based index
        input.nextLine(); // Consume the newline
    
        if (valueIndex < 0 || valueIndex >= values.size()) {
            System.out.println("Invalid value number. Please try again.");
            return; // Exit the method
        }
    
        String guessedValue = values.get(valueIndex);
    
        // Remove the guessed value from the trait's list of values
        chosenTrait.getValues().remove(guessedValue);
    
        // Check if the guessed value is correct
        if (guessedValue.equalsIgnoreCase(chosenTrait.getValue())) {
            System.out.println("Correct guess! The " + chosenTrait.getClass().getSimpleName() + " is " + guessedValue + ".");
            chosenTrait.markAsGuessed(); // Mark the entire trait as guessed
            // Remove all people who do not have this trait value
            people.removeIf(person -> !person.traits.get(traitIndex).getValue().equalsIgnoreCase(guessedValue));
        } else {
            System.out.println("Incorrect guess! The " + chosenTrait.getClass().getSimpleName() + " is not " + guessedValue + ".");
            // Remove all people who have this trait value
            people.removeIf(person -> person.traits.get(traitIndex).getValue().equalsIgnoreCase(guessedValue));
        }
    }
}