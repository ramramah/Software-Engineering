import java.util.Arrays;
public class Hair extends Trait {
    public Hair() {
        super(Arrays.asList("Black", "Brown", "Red", "Blond"));
    }
}
