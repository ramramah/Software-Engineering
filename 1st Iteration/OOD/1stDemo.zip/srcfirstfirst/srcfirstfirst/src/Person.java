import java.util.List;
import java.util.ArrayList;
public class Person {
    public List<Trait> traits;
    public boolean faceUp;
    public String name;
    public PersonType type;
    
    private List<Person> persons = new ArrayList<>();
    
    public static String[] names = {
            "Alice", "Bob", "Charlie", "Diana", "Eve", "Frank", "Grace", "Harry", 
            "Ivy", "Jack", "Karen", "Leo", "Mia", "Noah", "Olivia", "Peter", 
            "Quinn", "Rachel", "Steve", "Tina", "Uma", "Victor", "Wendy", 
            "Xavier", "Yvonne", "Zack"
        };

    public Person(String name){
        this.name = name;
        this.faceUp = true;
        traits = new ArrayList<>();
        traits.add(new Hair());
        traits.add(new Eye());
        traits.add(new Gender());
    }

    public Person(String name, PersonType type){
        this.name = name;
        this.type = type;
        this.faceUp = true;
        traits = new ArrayList<>();
        traits.add(new Hair());
        traits.add(new Eye());
        traits.add(new Gender());
    }
    
    public String getName() {
        return this.name;
    }
    public void display(){
        System.out.println("Name: " + this.name);
        for (Trait trait : traits) {
            System.out.println(trait);
        }
        System.out.println("--------------------"); // Separator line
    }
}



