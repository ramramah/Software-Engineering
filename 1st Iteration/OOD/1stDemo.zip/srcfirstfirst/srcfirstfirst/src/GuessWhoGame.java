import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GuessWhoGame {
    
    private List <Player> players = new ArrayList<>();
    

    public List<Player> getPlayers() {
		return players;
	}

	public void setPlayers(List<Player> players) {
		this.players = players;
	}
	
	
    static Scanner input = new Scanner(System.in);
	public static void main(String[] args) {
		
        System.out.println("Welcome to the Guess Who Game!");
        GuessWhoGame guessWhoGame = new GuessWhoGame();
      guessWhoGame.initGameBoard();

        input.close(); // Close the Scanner only once at the end
        System.out.println("Thank you for playing!");
    }

    static boolean promptForRestart() {
        // ... prompt for restart logic ...
        System.out.println("Would you like to play again? (yes/no): ");
        String response = input.nextLine().trim();
        return response.equalsIgnoreCase("yes");
    }
    
    public void initGameBoard(){
        boolean playAgain = true;
        while (playAgain) {
            initPlayers();      
            
            System.out.println("Choose Game Type:");
            System.out.println("1- Classic");
            System.out.println("2- Fantasy");
            System.out.println("3- Football");

            String s = input.nextLine();
            PersonType chosenType;

            if (s.equals("1")) {
            	chosenType = PersonType.CLASSIC;
            }
            else if (s.equals("2")) {
            	chosenType = PersonType.FANTASY;
            }
            else {
            	chosenType = PersonType.FOOTBALL;
            }
            
            // Create a new game board and start the game
            GameBoard gameBoard = new GameBoard(players, chosenType);      
            gameBoard.start(players); // Run the game round
            playAgain = promptForRestart(); // Prompt for restart after the game round  
            
        }
    }
    public String ChoseGuessNorT() {
        System.out.println("Would you like to guess the trait or the name? (T/N):");
        String response = input.nextLine().trim();
        return response;
    } 

    public int GuessTrait() {
        
        int traitIndex = input.nextInt() - 1; // Adjust for 0-based index
        input.nextLine(); // Consume the newline

        return traitIndex;
    }

    public int GuessName() {
        System.out.println("Choose the value to guess by number:");
        int valueIndex = input.nextInt() - 1; // Adjust for 0-based index
        input.nextLine(); // Consume the newline

        return valueIndex;
    }

    public List<Player> initPlayers() {
    	
         //here we can prompt the user to enter the number of players he wants
    	 int numberOfPlayers = 1;
    	 
    	 for (int i = 0; i<numberOfPlayers; ++i) {
        	 System.out.println("Enter player name:");
             String playerName = input.nextLine();
             System.out.println("Enter player ID:");
             String playerId = input.nextLine();
             Player player = new Player(playerName, playerId);
             players.add(player); 
    	 }
    	 
         return players;
    }

}



