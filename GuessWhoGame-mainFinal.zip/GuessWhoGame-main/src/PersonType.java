public enum PersonType {
	FANTASY,
	FOOTBALL,
	CLASSIC;	
}
