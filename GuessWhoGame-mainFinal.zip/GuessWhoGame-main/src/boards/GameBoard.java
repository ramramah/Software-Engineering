package boards;
import java.util.ArrayList;
import java.util.List;

import game.Guess;
import game.GuessWhoGame;
import game.Player;
import modes.GameModeStrategy;
import modes.P1VsP2Mode;
import modes.SinglePlayerMode;
import persons.Person;
import persons.PersonFactory;
import traits.Trait;
import persons.ClassicPersonFactory;

public class GameBoard {
	
    private List<Person> people;
    private PersonFactory personFactory;
    private Person target;
    private int faceUp, guessesMade;
    private Guess guessHandler = new Guess(people, target);
    private boolean gameEnded = false;
    private String[] names = Person.names;
    private Player player;
    private GameModeStrategy gameModeStrategy;
    private boolean nameGuessedCorrectly;
    private boolean nameGuessed = false;
    private GuessWhoGame game = GuessWhoGame.getInstance();
	public GameBoard() {}
	
    public GameBoard(Player player, GameModeStrategy gameModeStrategy,  PersonFactory personFactory) {
        this.people = new ArrayList<Person>();
        this.guessesMade = 0;
        this.faceUp = people.size();      
        this.player = player;
        this.gameModeStrategy = gameModeStrategy;
        this.personFactory = personFactory;
        initializeGame(gameModeStrategy);
    }
    
    public Person getTarget() {
		return target;
	}



	public void setTarget(Person target) {
		this.target = target;
	}



	public void updateGameState() {
        // This method might be called after a guess to update the game state
        this.faceUp = people.size(); // Update faceUp to the current number of "face up" people
        this.guessesMade++; // Increment guessesMade
    }

    
    public Guess getGuessHandler() {
		return guessHandler;
	}

	public void setGuessHandler(Guess guessHandler) {
		this.guessHandler = guessHandler;
	}

	public List<Person> getPeople() {
		return people;
	}

	public void setPeople(List<Person> people) {
		this.people = people;
	}

	
	public PersonFactory getPersonFactory() {
		return personFactory;
	}

	public void setPersonFactory(PersonFactory personFactory) {
		this.personFactory = personFactory;
	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}
	
	

	
	public GameModeStrategy getGameModeStrategy() {
		return gameModeStrategy;
	}

	public void setGameModeStrategy(GameModeStrategy gameModeStrategy) {
		this.gameModeStrategy = gameModeStrategy;
	}
	
	

	public boolean isNameGuessedCorrectly() {
		return nameGuessedCorrectly;
	}

	public void setNameGuessedCorrectly(boolean nameGuessedCorrectly) {
		this.nameGuessedCorrectly = nameGuessedCorrectly;
	}

	public boolean isNameGuessed() {
		return nameGuessed;
	}

	public void setNameGuessed(boolean nameGuessed) {
		this.nameGuessed = nameGuessed;
	}

	private void initializeGame(GameModeStrategy gameModeStrategy) {
        // Clear the current list of people
        people.clear();
        createPersons();    
       
        // Reset the number of people that are "faceUp" (still in the game)
        faceUp = people.size();
        
        // Reset the number of guesses made
        guessesMade = 0;
    }

    public ArrayList<Person> createPersons() {
    	ArrayList<Person> personList = new ArrayList<>();  	
    	
        for(int i = 0; i<26; ++i) {
        	Person person = personFactory.createPerson(Person.names[i]);
            personList.add(person);
        }        
        if (this.gameModeStrategy!= null && this.gameModeStrategy.getClass() == SinglePlayerMode.class) {
            this.people = personList;
        }
        return personList;         
    }
    
    
    
    public void start(GameModeStrategy gameModeStrategy, Person target) {
    	
//    	if (gameModeStrategy.getClass() == SinglePlayerMode.class) {
//            initializeGame(gameModeStrategy); // Set up the game
//    	}
//        
        
//        for (Player player: players) {

    		this.guessHandler = new Guess(people, target);

        	if (gameModeStrategy.getClass() == SinglePlayerMode.class) {
                game.display(this.people);
                
                while (!isNameGuessed()) {
                    game.display(this.people);
                    game.testTraitGuess(this, guessHandler); 
                }
        	}
        	
        	else if (gameModeStrategy.getClass() == P1VsP2Mode.class) {
        		game.display(this.people);
                game.testTraitGuess(this, guessHandler); 
        	}
        }
    
 
//        }
        
	
    // Now, after setting gameEnded to true, the method will end and return control to the calling method.
    

    public boolean guess(boolean forceNameGuess, Guess guessHandler) {
    	
        String guessType = "";
        
        if (forceNameGuess) guessType = "N";
        
        else {
        	guessType = game.GuessTorN();
        }
        
        if (guessType.equalsIgnoreCase("N")) {
            // Return the result of handleNameGuess which is now boolean
        	nameGuessed = true;
        	nameGuessedCorrectly = guessHandler.handleNameGuess();
            return nameGuessedCorrectly;
        } 
        else if (guessType.equalsIgnoreCase("T")) {
            this.people = guessHandler.handleTraitGuess(); // Assuming this method doesn't end the game
            return true; // Continue the game after a trait guess
        }
        else {
            System.out.println("Invalid input. Please enter 'T' for trait or 'N' for name.");
            return true; // Continue the game for invalid input
        }
    } 
    
    public Person generateRandomPerson(){
        Person target = people.get((int) (Math.random() * people.size()));
        return target;
    }

    // private void eliminate(int traitIndex, String guess) {
    //     Trait chosenTrait = target.traits.get(traitIndex);
    
    //     if (chosenTrait.getValue().equalsIgnoreCase(guess)) {
    //         // Correct guess: Remove all people not having this trait value
    //         people.removeIf(person -> 
    //             !person.traits.get(traitIndex).getValue().equalsIgnoreCase(guess));
    //         // Mark the trait as guessed
    //         chosenTrait.guessValue(guess);
    //     } else {
    //         // Incorrect guess: Keep all people who do not have this trait value
    //         people.removeIf(person -> 
    //             person.traits.get(traitIndex).getValue().equalsIgnoreCase(guess));
    //     }
    
    //     // Update the number of people still in the game
    //     faceUp = (int) people.stream().filter(p -> p.faceUp).count();
    // }    
}
