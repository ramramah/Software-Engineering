package modes;


public interface GameModeStrategy {
    void playGame();
}
