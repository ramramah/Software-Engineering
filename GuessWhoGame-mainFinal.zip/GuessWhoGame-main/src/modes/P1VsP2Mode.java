package modes;
import java.util.ArrayList;
import java.util.List;

import boards.GameBoard;
import game.Guess;
import game.Player;

import game.GuessWhoGame;
import persons.ClassicPersonFactory;
import persons.Person;

public class P1VsP2Mode implements GameModeStrategy {

	Person person = new Person();
	GuessWhoGame game = GuessWhoGame.getInstance();

	public void playGame() {
		
        boolean playAgain = true;

		while (playAgain) {

			GuessWhoGame game = GuessWhoGame.getInstance();

			List<Player> players = game.initPlayers(2);
			Player player1 = players.get(0);
			Player player2 = players.get(1);
			ClassicPersonFactory classicPersonFactory = new ClassicPersonFactory();
			GameBoard boardP1 = new GameBoard(player1, this, classicPersonFactory);
			GameBoard boardP2 = new GameBoard(player2, this, classicPersonFactory);
			GameBoard personGenerator = new GameBoard();
			personGenerator.setPersonFactory(classicPersonFactory);
			
			List<Person> personList = personGenerator.createPersons();
			
			boardP1.setPeople(new ArrayList<>(personList));
			
			game.display(boardP1.getPeople());

			String player1TargetString = game.ChooseTarget(2, 1);
			Person player1Target = person.getPersonFromIndex(Integer.parseInt(player1TargetString),
					boardP1.getPeople());
			boardP1.setPlayer(player1);
			boardP1.setTarget(player1Target);
			boardP1.setGuessHandler(new Guess(boardP1.getPeople(), player1Target));

			boardP2.setPeople(new ArrayList<>(personList));
			
			String player2TargetString = game.ChooseTarget(1, 2);
			Person player2Target = person.getPersonFromIndex(Integer.parseInt(player2TargetString),
					boardP2.getPeople());
			boardP2.setPlayer(player2);
			boardP2.setTarget(player2Target);
			boardP2.setGuessHandler(new Guess(boardP2.getPeople(), player2Target));
			
			// Rest of your P1 vs P2 logic here

			boolean gameContinues = true;

			while (gameContinues) {
				System.out.println("\n\nplayer 1 Turn\n\n");

				game.startGameBoard(boardP1, this, player1Target);
				if (boardP1.isNameGuessed()) {
					gameContinues = false;
					if (boardP1.isNameGuessedCorrectly()) {
						game.printer("player 1 wins", true);
						break;
					} else {
						Boolean board2Result = game.forceNameGuess(boardP2, player2Target);
						if (board2Result == true) {
							game.printer("player 2 wins", true);
							break;

						} else {
							game.printer("Draw", true);
							break;
						}
						//
					}

				}

				System.out.println("\n\nplayer 2 Turn\n\n");

				game.startGameBoard(boardP2, this, player2Target);
				if (boardP2.isNameGuessed()) {
					gameContinues = false;
					if (boardP2.isNameGuessedCorrectly()) {
						game.printer("player 2 wins", true);
						break;

					} else {
						//
						Boolean board1Result = game.forceNameGuess(boardP1, player1Target);

						if (board1Result == true) {
							game.printer("player 1 wins", true);
							break;

						} else {
							game.printer("Draw", true);
							break;

						}

					}
				}
			}
            playAgain = GuessWhoGame.RestartGame();
		}
		
	}

}
