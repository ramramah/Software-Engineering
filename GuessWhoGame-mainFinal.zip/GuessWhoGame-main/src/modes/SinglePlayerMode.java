package modes;
import java.util.List;

import boards.GameBoard;
import game.GuessWhoGame;
import game.Player;
import persons.ClassicPersonFactory;
import persons.Person;

public class SinglePlayerMode implements GameModeStrategy {
    @Override
    public void playGame() {
    	
        boolean playAgain = true;
        
        while (playAgain) {
        	GuessWhoGame game = GuessWhoGame.getInstance();
            List<Player> players = game.initPlayers(1);
			ClassicPersonFactory classicPersonFactory = new ClassicPersonFactory();
			
            GameBoard gameBoard = new GameBoard(players.get(0), this, classicPersonFactory);
            Person target = gameBoard.generateRandomPerson();
            gameBoard.setTarget(target);
            
			game.startGameBoard(gameBoard, this, target);
            playAgain = GuessWhoGame.RestartGame();
        }
    }
    
    
}