package game;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import boards.GameBoard;
import modes.GameModeStrategy;
import modes.P1VsP2Mode;
import modes.SinglePlayerMode;
import persons.Person;

public class GuessWhoGame {
    
    private List <Player> players = new ArrayList<>();
    private static GameModeStrategy gameMode;
    private static GuessWhoGame instance;
    public List<Player> getPlayers() {
		return players;
	}

	public void setPlayers(List<Player> players) {
		this.players = players;
	}
	private GuessWhoGame () {}
	
    public static GuessWhoGame getInstance() {
        if (instance == null) {
            instance = new GuessWhoGame();
        }
        return instance;
    }
	
    static Scanner input = new Scanner(System.in);
    
	public static void main(String[] args) {
		GuessWhoGame game =  getInstance();
		game.startNewGame(gameMode);
    }
	
	
	//rename to startNewGame
	public void startNewGame(GameModeStrategy gameMode) {
		
	    System.out.println("Welcome to the Guess Who Game!");
	    System.out.println("Choose Game Mode:");
	    System.out.println("1- Single Player");
	    System.out.println("2- P1 vs P2");
	    String mode = input.nextLine();

	    if (mode.equals("1")) {
	        gameMode = new SinglePlayerMode();
	        
	    } else if (mode.equals("2")) {    	
	        gameMode = new P1VsP2Mode();
	        
	    } else {
	        System.out.println("Invalid selection. Please choose 1 or 2.");
	        startNewGame(gameMode);
	        return;
	    }
	    gameMode.playGame();	
	  }
	
   public boolean testTraitGuess(GameBoard gameBoard, Guess guessHandler) {
    	return gameBoard.guess(false, guessHandler);
    }


	public void startGameBoard(GameBoard gameBoard, GameModeStrategy gameModeStrategy, Person target) {
        gameBoard.start(gameModeStrategy, target);
	}
	
	public boolean forceNameGuess(GameBoard gameBoard, Person target) {
		gameBoard.guess(true, gameBoard.getGuessHandler());
         return gameBoard.isNameGuessedCorrectly();
	}

	
    public static boolean RestartGame() {
        // ... prompt for restart logic ...
        System.out.println("Would you like to play again? (yes/no): ");
        String response = input.nextLine().trim();
        return response.equalsIgnoreCase("yes");
    }
    
    public List<Player> initPlayers(int numberOfPlayers) {
    	
         //here we can prompt the user to enter the number of players he wants
    	 
    	 for (int i = 0; i<numberOfPlayers; ++i) {
        	 System.out.println("Enter player name:");
             String playerName = input.nextLine();
             System.out.println("Enter player ID:");
             String playerId = input.nextLine();
             Player player = new Player(playerName, playerId);
             players.add(player);              
    	 }
    	 
         return players;
    }
    
    public String GuessTorN() {
        System.out.println("Would you like to guess the trait or the name? (T/N):");
        String response = input.nextLine().trim();
        return response;
    }
    
    public String ChooseTarget(int one, int two) {
	    System.out.println("Player " + one + " pick the target for player " + two + ": ");
        String target = input.nextLine().trim();
        return target;
    }
    
    public int  nameGuess(List<Person> people){
    	
        System.out.println("Choose a name to guess from the list:");
        for (int i = 0; i < people.size(); i++) {
            if (people.get(i).faceUp) { // Assuming that the 'faceUp' attribute indicates if a character is still in the game
                System.out.println((i + 1) + ". " + people.get(i).name);
            }
        }
        
        System.out.println("Enter the number of the name you want to guess:");
        
        int nameIndex = input.nextInt() - 1; // Adjust for 0-based index
        input.nextLine(); // Consume the newline

	   return nameIndex;
   }
    
    public int GuessTrait() {
        System.out.println("Choose a trait to guess by number:");
        int traitIndex = input.nextInt() - 1; // Adjust for 0-based index
        input.nextLine(); // Consume the newline

        return traitIndex;
    }

    public int GuessTraitValue() {
        System.out.println("Choose the value to guess by number:");
        int valueIndex = input.nextInt() - 1; // Adjust for 0-based index
        input.nextLine(); // Consume the newline

        return valueIndex;
    }
    
    
    public void display(List<Person> people) {
    	int i = 1;
        for (Person person : people) {
            if (person.faceUp) {
                person.display(i);
                i++;
            }
        }
    }
    
    public void printer(String stringToPrint, boolean isLineEnding) {       	
    	if (isLineEnding) {
    		System.out.println(stringToPrint);
    	}
    	else {
        	System.out.print(stringToPrint);    		
    	}    
    }
 

}
