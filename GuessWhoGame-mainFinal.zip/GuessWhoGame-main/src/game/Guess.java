package game;
import java.util.List;
import java.util.Scanner;

import persons.Person;
import traits.Trait;
import helpers.*; 


public class Guess {
    private List<Person> people;
    private Person target;
    
    private GuessWhoGame game = GuessWhoGame.getInstance();
    
    public Guess(List<Person> people, Person target) {
        this.people = people;
        this.target = target;
    }

	Scanner input = new Scanner(System.in);
	
    public boolean handleNameGuess() {
        // Display the list of names of characters that are still in the game
    	int nameIndex = game.nameGuess(people);
    	
        // Check if the input is within the valid range
        if (nameIndex < 0 || nameIndex >= people.size() || !people.get(nameIndex).faceUp) {
        	game.printer(OutputConstants.INVALID_GUESS, true);
            return true; // Exit the method if the number is not valid
        }
    
        String guessedName = people.get(nameIndex).name;
        if (guessedName.equalsIgnoreCase(target.name)) {
        	game.printer(OutputConstants.CORRECT_GUESS, true);
        	game.printer(OutputConstants.GAME_WON, true);
            return true; // Return false to indicate that the game should end
        } else {
        	game.printer(OutputConstants.INCORRECT_GUESS, false);
        	game.printer("The character ", false);
        	game.printer(guessedName, false);
        	game.printer(OutputConstants.NOT_CORRECT, true);
        	
        	
        	game.printer(OutputConstants.TARGET_IS, false);
        	game.printer(target.getName(), true);
            return false; // Return false to indicate that the game should end
        }
    }

    
    // This method prompts the player to guess a trait and returns the selected trait's index.
    public List<Person> handleTraitGuess() {
        // Display the list of traits with numbers
        for (int i = 0; i < target.traits.size(); i++) {
            System.out.println((i + 1) + ". " + target.traits.get(i).getClass().getSimpleName());
        }
    
        int traitIndex = game.GuessTrait();
    
        if (traitIndex < 0 || traitIndex >= target.traits.size()) {
            System.out.println("Invalid trait number. Please try again.");
            return null; // Exit the method
        }
    
        // Display the list of possible values for the chosen trait with numbers
        Trait chosenTrait = target.traits.get(traitIndex);
        List<String> values = chosenTrait.getValues();
        for (int i = 0; i < values.size(); i++) {
            System.out.println((i + 1) + ". " + values.get(i));
        }
    
        int valueIndex = game.GuessTraitValue();
    
        if (valueIndex < 0 || valueIndex >= values.size()) {
            System.out.println("Invalid value number. Please try again.");
            return null; // Exit the method
        }
    
        String guessedValue = values.get(valueIndex);
    
        // Remove the guessed value from the trait's list of values
        chosenTrait.getValues().remove(guessedValue);
    
        // Check if the guessed value is correct
        if (guessedValue.equalsIgnoreCase(chosenTrait.getValue())) {
        	game.printer(OutputConstants.CORRECT_GUESS, false);
        	game.printer(chosenTrait.getClass().getSimpleName() + " is " + guessedValue + ".", true);
            chosenTrait.markAsGuessed(); // Mark the entire trait as guessed
            // Remove all people who do not have this trait value
            people.removeIf(person -> !person.traits.get(traitIndex).getValue().equalsIgnoreCase(guessedValue));
        } else {
        	game.printer(OutputConstants.INCORRECT_GUESS, false);
        	game.printer(chosenTrait.getClass().getSimpleName() + " is not " + guessedValue + ".", true);
            // Remove all people who have this trait value
            people.removeIf(person -> person.traits.get(traitIndex).getValue().equalsIgnoreCase(guessedValue));
        }
        
        return people;
    }
}