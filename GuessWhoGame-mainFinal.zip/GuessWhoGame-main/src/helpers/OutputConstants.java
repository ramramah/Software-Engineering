package helpers;
public class OutputConstants {
	
	public static final String INVALID_GUESS = "Invalid number or character already eliminated. Please try again.";
	public static final String CORRECT_GUESS = "Correct guess! ";
	public static final String GAME_WON = "You've won the game";
	public static final String INCORRECT_GUESS = "Incorrect guess! ";
	public static final String NOT_CORRECT = " is not the target.";
	public static final String TARGET_IS = "The target was ";
	  
}
