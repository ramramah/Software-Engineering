package persons;

public interface PersonFactory {
    Person createPerson(String name);
}