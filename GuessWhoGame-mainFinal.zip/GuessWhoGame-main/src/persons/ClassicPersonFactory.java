package persons;
public class ClassicPersonFactory implements PersonFactory {	
	
	   @Override
	    public Person createPerson(String name) {
	        return new Person(name);
	    }
}