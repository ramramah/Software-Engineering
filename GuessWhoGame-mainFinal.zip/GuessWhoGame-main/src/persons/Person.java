package persons;
import java.util.List;

import traits.Eye;
import traits.Gender;
import traits.Hair;
import traits.Trait;

import java.util.ArrayList;
public class Person {
    public List<Trait> traits;
    public boolean faceUp;
    public String name;
//    public PersonType type;
    
    
    public static String[] names = {
            "Alice", "Bob", "Charlie", "Diana", "Eve", "Frank", "Grace", "Harry", 
            "Ivy", "Jack", "Karen", "Leo", "Mia", "Noah", "Olivia", "Peter", 
            "Quinn", "Rachel", "Steve", "Tina", "Uma", "Victor", "Wendy", 
            "Xavier", "Yvonne", "Zack"
        };
    
    public Person() {
    }

    public Person(String name){
        this.name = name;
        this.faceUp = true;
        traits = new ArrayList<>();
        traits.add(new Hair());
        traits.add(new Eye());
        traits.add(new Gender());
    }
    

    public String getName() {
        return this.name;
    }
    public void display(int i){
        System.out.println(i + "- Name: " + this.name);
        for (Trait trait : traits) {
            System.out.println(trait);
        }
        System.out.println("--------------------"); // Separator line
    }
    
    
    public Person getPersonFromIndex(int index, List<Person> personList) {
        if (index >= 0 && index < personList.size()) {
            return personList.get(index-1);
        } 
        else {
            // Handle index out of bounds or return null as appropriate for your use case
            return null;
        }
    }}



